package clubdeportivo.deportes;

import java.util.ArrayList;
import java.util.List;

public class Competencia {

    private String nombreCompetencia;
    private String entidadOrganizadora;
    private int temporada;
    private String formatoJuego;
    private List<InscripcionCompetencia> inscripciones;
    private List<FaseCompetencia> fases;

    public Competencia(
            String nombreCompetencia,
            String entidadOrganizadora,
            int temporada,
            String formatoJuego) {
        this.nombreCompetencia = nombreCompetencia;
        this.entidadOrganizadora = entidadOrganizadora;
        this.temporada = temporada;
        this.formatoJuego = formatoJuego;
        this.inscripciones =
                new ArrayList<InscripcionCompetencia>();
        this.fases = new ArrayList<FaseCompetencia>();
    }

    public boolean validarInscripcion(
            InscripcionCompetencia inscripcion) {
        if (inscripcion == null
                || !inscripcion.validarRequisitos()) {
            return false;
        }

        for (InscripcionCompetencia actual : inscripciones) {
            if (actual.getEquipo() == inscripcion.getEquipo()) {
                return false;
            }
        }

        return true;
    }

    public boolean registrarInscripcion(
            InscripcionCompetencia inscripcion) {
        if (!validarInscripcion(inscripcion)) {
            return false;
        }

        inscripciones.add(inscripcion);
        return true;
    }

    public void agregarFase(FaseCompetencia fase) {
        if (fase != null && !fases.contains(fase)) {
            fases.add(fase);
        }
    }

    public List<String> calcularTablaPosiciones() {
        List<String> tabla = new ArrayList<String>();

        for (FaseCompetencia fase : fases) {
            tabla.addAll(fase.calcularPosiciones());
        }

        return tabla;
    }

    public String getNombreCompetencia() {
        return nombreCompetencia;
    }

    public String getEntidadOrganizadora() {
        return entidadOrganizadora;
    }

    public int getTemporada() {
        return temporada;
    }

    public String getFormatoJuego() {
        return formatoJuego;
    }

    public List<InscripcionCompetencia> getInscripciones() {
        return new ArrayList<InscripcionCompetencia>(inscripciones);
    }

    public List<FaseCompetencia> getFases() {
        return new ArrayList<FaseCompetencia>(fases);
    }
}
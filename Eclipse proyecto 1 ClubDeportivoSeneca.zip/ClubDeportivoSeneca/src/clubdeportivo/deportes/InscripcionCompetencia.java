package clubdeportivo.deportes;

import java.time.LocalDate;
import clubdeportivo.Equipo;

public class InscripcionCompetencia {

    private Equipo equipo;
    private LocalDate fechaInscripcion;
    private String estado;

    public InscripcionCompetencia(
            Equipo equipo,
            LocalDate fechaInscripcion) {
        this.equipo = equipo;
        this.fechaInscripcion = fechaInscripcion;
        this.estado = "PENDIENTE";
    }

    public boolean validarRequisitos() {
        return equipo != null
                && fechaInscripcion != null
                && "ACEPTADA".equals(estado);
    }

    public void registrarNomina() {
        if (equipo != null) {
            estado = "ACEPTADA";
        }
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public LocalDate getFechaInscripcion() {
        return fechaInscripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
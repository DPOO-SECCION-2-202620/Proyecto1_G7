package clubdeportivo.deportes;

public class Ejercicio {

    private String nombre;
    private int series;
    private int repeticiones;

    public Ejercicio(String nombre, int series, int repeticiones) {
        this.nombre = nombre;
        this.series = series;
        this.repeticiones = repeticiones;
    }

    public boolean validarParametros() {
        return nombre != null
                && !nombre.trim().isEmpty()
                && series > 0
                && repeticiones > 0;
    }

    public String getNombre() {
        return nombre;
    }

    public int getSeries() {
        return series;
    }

    public int getRepeticiones() {
        return repeticiones;
    }
}
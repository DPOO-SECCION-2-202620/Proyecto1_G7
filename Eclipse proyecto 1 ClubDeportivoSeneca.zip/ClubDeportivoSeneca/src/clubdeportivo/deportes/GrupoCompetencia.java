package clubdeportivo.deportes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import clubdeportivo.Equipo;

public class GrupoCompetencia {

    private String nombreGrupo;
    private List<Equipo> equipos;
    private List<Partido> partidos;
    private List<String> tablaPosiciones;

    public GrupoCompetencia(String nombreGrupo) {
        this.nombreGrupo = nombreGrupo;
        this.equipos = new ArrayList<Equipo>();
        this.partidos = new ArrayList<Partido>();
        this.tablaPosiciones = new ArrayList<String>();
    }

    public boolean agregarEquipo(Equipo equipo) {
        if (equipo == null || equipos.contains(equipo)) {
            return false;
        }

        equipos.add(equipo);
        return true;
    }

    public boolean agregarPartido(Partido partido) {
        if (partido == null || !partido.puedeDisputarse()
                || !equipos.contains(partido.getEquipoLocal())
                || !equipos.contains(partido.getEquipoVisitante())) {
            return false;
        }

        for (Partido existente : partidos) {
            if (existente.getId().equalsIgnoreCase(partido.getId())) {
                return false;
            }
        }

        partidos.add(partido);
        return true;
    }

    public List<String> calcularPosiciones() {
        Map<Equipo, int[]> datos = new HashMap<Equipo, int[]>();

        for (Equipo equipo : equipos) {
            datos.put(equipo, new int[7]);
        }

        for (Partido partido : partidos) {
            Equipo local = partido.getEquipoLocal();
            Equipo visitante = partido.getEquipoVisitante();

            int golesLocal = partido.getMarcadorLocal();
            int golesVisitante = partido.getMarcadorVisitante();

            int[] datosLocal = datos.get(local);
            int[] datosVisitante = datos.get(visitante);

            datosLocal[0]++;
            datosVisitante[0]++;

            datosLocal[4] += golesLocal;
            datosLocal[5] += golesVisitante;
            datosVisitante[4] += golesVisitante;
            datosVisitante[5] += golesLocal;

            if (golesLocal > golesVisitante) {
                datosLocal[1]++;
                datosLocal[6] += 3;
                datosVisitante[3]++;
            } else if (golesLocal < golesVisitante) {
                datosVisitante[1]++;
                datosVisitante[6] += 3;
                datosLocal[3]++;
            } else {
                datosLocal[2]++;
                datosVisitante[2]++;
                datosLocal[6]++;
                datosVisitante[6]++;
            }
        }

        List<Equipo> ordenados = new ArrayList<Equipo>(equipos);

        Collections.sort(ordenados, new Comparator<Equipo>() {
            @Override
            public int compare(Equipo primero, Equipo segundo) {
                int[] datosPrimero = datos.get(primero);
                int[] datosSegundo = datos.get(segundo);

                int compararPuntos = Integer.compare(
                        datosSegundo[6], datosPrimero[6]
                );

                if (compararPuntos != 0) {
                    return compararPuntos;
                }

                int diferenciaPrimero =
                        datosPrimero[4] - datosPrimero[5];
                int diferenciaSegundo =
                        datosSegundo[4] - datosSegundo[5];

                int compararDiferencia = Integer.compare(
                        diferenciaSegundo, diferenciaPrimero
                );

                if (compararDiferencia != 0) {
                    return compararDiferencia;
                }

                return primero.getNombreEquipo()
                        .compareToIgnoreCase(segundo.getNombreEquipo());
            }
        });

        tablaPosiciones.clear();

        for (int i = 0; i < ordenados.size(); i++) {
            Equipo equipo = ordenados.get(i);
            int[] d = datos.get(equipo);

            tablaPosiciones.add(
                    (i + 1) + ". " + equipo.getNombreEquipo()
                    + " | Puntos: " + d[6]
                    + " | PJ: " + d[0]
                    + " | PG: " + d[1]
                    + " | PE: " + d[2]
                    + " | PP: " + d[3]
                    + " | GF: " + d[4]
                    + " | GC: " + d[5]
            );
        }

        return new ArrayList<String>(tablaPosiciones);
    }

    public String getNombreGrupo() {
        return nombreGrupo;
    }

    public List<Equipo> getEquipos() {
        return new ArrayList<Equipo>(equipos);
    }

    public List<Partido> getPartidos() {
        return new ArrayList<Partido>(partidos);
    }

    public List<String> getTablaPosiciones() {
        return new ArrayList<String>(tablaPosiciones);
    }
}
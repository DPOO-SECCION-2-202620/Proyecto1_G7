package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public class Sancion {

    private PerfilJugador jugador;
    private String motivo;
    private int partidosPendientes;
    private boolean cumplida;

    public Sancion(PerfilJugador jugador, String motivo,
            int partidosPendientes) {
        this.jugador = jugador;
        this.motivo = motivo;
        this.partidosPendientes = Math.max(0, partidosPendientes);
        this.cumplida = partidosPendientes <= 0;
    }

    public int calcularSuspension() {
        return partidosPendientes;
    }

    public void aplicarSuspension() {
        if (partidosPendientes > 0) {
            partidosPendientes--;
        }

        if (partidosPendientes == 0) {
            cumplida = true;
        }
    }

    public PerfilJugador getJugador() {
        return jugador;
    }

    public String getMotivo() {
        return motivo;
    }

    public int getPartidosPendientes() {
        return partidosPendientes;
    }

    public boolean isCumplida() {
        return cumplida;
    }
}
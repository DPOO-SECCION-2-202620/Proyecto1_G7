package clubdeportivo.deportes;

public class Padel extends DeporteIndividual {

    private String modalidad;

    public Padel(String modalidad) {
        super("Padel");
        this.modalidad = modalidad;
    }

    @Override
    public boolean validarModalidad() {
        return "Dobles".equalsIgnoreCase(modalidad)
                || "Mixto".equalsIgnoreCase(modalidad);
    }

    public String getModalidad() {
        return modalidad;
    }
}
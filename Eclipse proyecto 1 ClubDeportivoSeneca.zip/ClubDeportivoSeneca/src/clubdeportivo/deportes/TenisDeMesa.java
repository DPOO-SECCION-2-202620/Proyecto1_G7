package clubdeportivo.deportes;

public class TenisDeMesa {

}

package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public abstract class EstadisticaPartido {

    private Partido partido;
    private PerfilJugador jugador;

    public EstadisticaPartido(
            Partido partido,
            PerfilJugador jugador) {
        this.partido = partido;
        this.jugador = jugador;
    }

    public abstract void actualizarEstadisticas();

    public Partido getPartido() {
        return partido;
    }

    public PerfilJugador getJugador() {
        return jugador;
    }
}
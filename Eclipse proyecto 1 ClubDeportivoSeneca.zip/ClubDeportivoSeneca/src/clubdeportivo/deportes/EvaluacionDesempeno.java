package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public class EvaluacionDesempeno {

    private final Entrenamiento entrenamiento;
    private final PerfilJugador jugador;
    private final int calificacion;
    private final String observacion;

    public EvaluacionDesempeno(
            Entrenamiento entrenamiento,
            PerfilJugador jugador,
            int calificacion,
            String observacion) {

        if (entrenamiento == null || jugador == null
                || calificacion < 1 || calificacion > 5) {
            throw new IllegalArgumentException(
                    "Datos de evaluacion invalidos.");
        }

        this.entrenamiento = entrenamiento;
        this.jugador = jugador;
        this.calificacion = calificacion;
        this.observacion = observacion == null ? "" : observacion;
    }

    public Entrenamiento getEntrenamiento() {
        return entrenamiento;
    }

    public PerfilJugador getJugador() {
        return jugador;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public String getObservacion() {
        return observacion;
    }
}
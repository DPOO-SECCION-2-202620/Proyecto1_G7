package clubdeportivo.deportes;

import java.time.LocalDate;
import clubdeportivo.Equipo;

public class PartidoInterno extends Partido {

    public PartidoInterno(String id, LocalDate fecha,
            Equipo equipoLocal, Equipo equipoVisitante) {
        super(id, fecha, equipoLocal, equipoVisitante);
    }

    @Override
    public boolean puedeDisputarse() {
        return validarEquipos();
    }

    public boolean registrarResultado(
            int marcadorLocal, int marcadorVisitante) {
        if (!puedeDisputarse()) {
            return false;
        }

        return registrarMarcador(marcadorLocal, marcadorVisitante);
    }

    public String obtenerResultado() {
        return getEquipoLocal().getNombreEquipo()
                + " " + getMarcadorLocal()
                + " - " + getMarcadorVisitante()
                + " " + getEquipoVisitante().getNombreEquipo();
    }
}
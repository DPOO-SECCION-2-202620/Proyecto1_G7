package clubdeportivo.deportes;

import java.time.LocalDate;
import clubdeportivo.Equipo;

public abstract class Partido {

    private String id;
    private LocalDate fecha;
    private int marcadorLocal;
    private int marcadorVisitante;
    private Equipo equipoLocal;
    private Equipo equipoVisitante;

    public Partido(String id, LocalDate fecha,
            Equipo equipoLocal, Equipo equipoVisitante) {
        this.id = id;
        this.fecha = fecha;
        this.equipoLocal = equipoLocal;
        this.equipoVisitante = equipoVisitante;
        this.marcadorLocal = 0;
        this.marcadorVisitante = 0;
    }

    public boolean validarEquipos() {
        if (equipoLocal == null || equipoVisitante == null) {
            return false;
        }

        if (equipoLocal == equipoVisitante) {
            return false;
        }

        return equipoLocal.getDeporte().getNombre()
                .equalsIgnoreCase(
                        equipoVisitante.getDeporte().getNombre());
    }

    public boolean registrarMarcador(
            int marcadorLocal, int marcadorVisitante) {
        if (marcadorLocal < 0 || marcadorVisitante < 0) {
            return false;
        }

        this.marcadorLocal = marcadorLocal;
        this.marcadorVisitante = marcadorVisitante;
        return true;
    }

    public abstract boolean puedeDisputarse();

    public String getId() {
        return id;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getMarcadorLocal() {
        return marcadorLocal;
    }

    public int getMarcadorVisitante() {
        return marcadorVisitante;
    }

    public Equipo getEquipoLocal() {
        return equipoLocal;
    }

    public Equipo getEquipoVisitante() {
        return equipoVisitante;
    }
}
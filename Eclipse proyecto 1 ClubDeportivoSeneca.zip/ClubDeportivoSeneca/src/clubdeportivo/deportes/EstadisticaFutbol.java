package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public class EstadisticaFutbol extends EstadisticaPartido {

    private int goles;
    private int asistencias;
    private int tarjetasAmarillas;
    private int tarjetasRojas;

    public EstadisticaFutbol(Partido partido, PerfilJugador jugador) {
        super(partido, jugador);
    }

    public void registrarGoles(int cantidad) {
        if (cantidad >= 0) {
            goles += cantidad;
        }
    }

    public void registrarAsistencias(int cantidad) {
        if (cantidad >= 0) {
            asistencias += cantidad;
        }
    }

    public void registrarTarjetaAmarilla() {
        tarjetasAmarillas++;
    }

    public void registrarTarjetaRoja() {
        tarjetasRojas++;
    }

    @Override
    public void actualizarEstadisticas() {
        
    }

    public int getGoles() {
        return goles;
    }

    public int getAsistencias() {
        return asistencias;
    }

    public int getTarjetasAmarillas() {
        return tarjetasAmarillas;
    }

    public int getTarjetasRojas() {
        return tarjetasRojas;
    }
}
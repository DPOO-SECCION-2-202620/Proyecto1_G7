package clubdeportivo.deportes;

public class PartidoOficial {

}

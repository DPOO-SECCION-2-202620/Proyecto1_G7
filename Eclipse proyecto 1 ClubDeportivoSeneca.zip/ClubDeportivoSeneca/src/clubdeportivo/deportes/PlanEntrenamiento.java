package clubdeportivo.deportes;

import java.util.ArrayList;
import java.util.List;

public class PlanEntrenamiento {

    private String objetivo;
    private String descripcion;
    private List<Ejercicio> ejercicios;

    public PlanEntrenamiento(String objetivo, String descripcion) {
        this.objetivo = objetivo;
        this.descripcion = descripcion;
        this.ejercicios = new ArrayList<>();
    }

    public boolean agregarEjercicio(Ejercicio ejercicio) {
        if (ejercicio == null || !ejercicio.validarParametros()) {
            return false;
        }

        ejercicios.add(ejercicio);
        return true;
    }

    public int calcularDuracion() {
        int duracionTotal = 0;

        for (Ejercicio ejercicio : ejercicios) {
            duracionTotal += ejercicio.getSeries()
                    * ejercicio.getRepeticiones();
        }

        return duracionTotal;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Ejercicio> getEjercicios() {
        return new ArrayList<>(ejercicios);
    }
}
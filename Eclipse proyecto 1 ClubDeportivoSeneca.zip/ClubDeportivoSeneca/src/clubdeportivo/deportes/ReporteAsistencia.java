package clubdeportivo.deportes;

import java.util.List;
import clubdeportivo.PerfilJugador;

public class ReporteAsistencia {

    public String generarResumen(
            ControlEntrenamientos control,
            PerfilJugador jugador) {

        if (control == null || jugador == null) {
            return "No se pudo generar el reporte.";
        }

        List<RegistroAsistencia> registros =
                control.consultarAsistencias(jugador);

        int presentes = 0;
        int ausenciasJustificadas = 0;

        for (RegistroAsistencia registro : registros) {
            if ("PRESENTE".equalsIgnoreCase(registro.getEstado())) {
                presentes++;
            } else if ("AUSENCIA JUSTIFICADA"
                    .equalsIgnoreCase(registro.getEstado())) {
                ausenciasJustificadas++;
            }
        }

        return "Entrenamientos registrados: " + registros.size()
                + "\nAsistencias: " + presentes
                + "\nAusencias justificadas: " + ausenciasJustificadas
                + "\nPorcentaje de asistencia: "
                + String.format("%.1f", control.porcentajeAsistencia(jugador))
                + "%";
    }
}
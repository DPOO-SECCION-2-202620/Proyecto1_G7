package clubdeportivo.deportes;

import java.time.LocalDateTime;

public class PartidoPractica {

    private LocalDateTime fechaHora;
    private String modalidad;
    private boolean resultadoRegistrado;

    public PartidoPractica(LocalDateTime fechaHora, String modalidad) {
        this.fechaHora = fechaHora;
        this.modalidad = modalidad;
        this.resultadoRegistrado = false;
    }

    public boolean validarNiveles() {
        return fechaHora != null
                && modalidad != null
                && !modalidad.trim().isEmpty();
    }

    public boolean registrarResultado() {
        if (!validarNiveles()) {
            return false;
        }

        resultadoRegistrado = true;
        return true;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public String getModalidad() {
        return modalidad;
    }

    public boolean isResultadoRegistrado() {
        return resultadoRegistrado;
    }
}
package clubdeportivo.deportes;

import java.util.List;
import clubdeportivo.PerfilJugador;

public class ReporteEvaluaciones {

    public String generarResumen(
            ControlEvaluaciones control,
            PerfilJugador jugador) {

        if (control == null || jugador == null
                || jugador.getUsuario() == null) {
            return "No se pudo generar el reporte.";
        }

        List<EvaluacionDesempeno> evaluaciones =
                control.consultar(jugador);

        StringBuilder resumen = new StringBuilder();

        resumen.append("Evaluaciones de ")
                .append(jugador.getUsuario().getLogin())
                .append(":\n");

        for (EvaluacionDesempeno evaluacion : evaluaciones) {
            resumen.append("- ")
                    .append(evaluacion.getEntrenamiento().getTipo())
                    .append(": ")
                    .append(evaluacion.getCalificacion())
                    .append("/5");

            if (!evaluacion.getObservacion().isBlank()) {
                resumen.append(" (")
                        .append(evaluacion.getObservacion())
                        .append(")");
            }

            resumen.append("\n");
        }

        resumen.append("Promedio: ")
                .append(String.format(
                        "%.2f", control.calcularPromedio(jugador)));

        return resumen.toString();
    }
}
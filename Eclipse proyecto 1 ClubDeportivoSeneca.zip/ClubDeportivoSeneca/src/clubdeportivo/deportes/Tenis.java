package clubdeportivo.deportes;

public class Tenis extends DeporteIndividual {

    private String modalidad;

    public Tenis(String modalidad) {
        super("Tenis");
        this.modalidad = modalidad;
    }

    @Override
    public boolean validarModalidad() {
        return "Individual".equalsIgnoreCase(modalidad)
                || "Dobles".equalsIgnoreCase(modalidad);
    }

    public String getModalidad() {
        return modalidad;
    }
}
package clubdeportivo.deportes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import clubdeportivo.PerfilJugador;

public class ControlHabilitacionesMedicas {

    private final List<HabilitacionMedica> habilitaciones =
            new ArrayList<HabilitacionMedica>();

    public boolean registrar(HabilitacionMedica habilitacion) {
        if (habilitacion == null
                || habilitacion.getJugador() == null
                || habilitacion.getJugador().getUsuario() == null) {
            return false;
        }

        habilitaciones.add(habilitacion);
        return true;
    }

    public boolean estaHabilitado(
            PerfilJugador jugador,
            LocalDate fecha) {

        if (jugador == null || jugador.getUsuario() == null
                || fecha == null) {
            return false;
        }

        String login = jugador.getUsuario().getLogin();

        for (int i = habilitaciones.size() - 1; i >= 0; i--) {
            HabilitacionMedica actual = habilitaciones.get(i);

            String loginActual = actual.getJugador()
                    .getUsuario()
                    .getLogin();

            if (login.equalsIgnoreCase(loginActual)) {
                return actual.estaVigente(fecha);
            }
        }

        return false;
    }

    public List<HabilitacionMedica> getHabilitaciones() {
        return Collections.unmodifiableList(habilitaciones);
    }
}
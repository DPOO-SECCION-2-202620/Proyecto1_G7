package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public class EstadisticaVoleibol extends EstadisticaPartido {

    private int aces;
    private int bloqueos;

    public EstadisticaVoleibol(Partido partido,
            PerfilJugador jugador) {
        super(partido, jugador);
    }

    public void registrarAces(int cantidad) {
        if (cantidad >= 0) {
            aces += cantidad;
        }
    }

    public void registrarBloqueos(int cantidad) {
        if (cantidad >= 0) {
            bloqueos += cantidad;
        }
    }

    @Override
    public void actualizarEstadisticas() {
        // Los valores se actualizan al registrar cada evento.
    }

    public int getAces() {
        return aces;
    }

    public int getBloqueos() {
        return bloqueos;
    }
}
package clubdeportivo.deportes;

import java.time.LocalDateTime;
import clubdeportivo.PerfilJugador;

public class RegistroAsistencia {

    private Entrenamiento entrenamiento;
    private PerfilJugador jugador;
    private LocalDateTime fechaHora;
    private String estado;

    public RegistroAsistencia(Entrenamiento entrenamiento,
            PerfilJugador jugador, LocalDateTime fechaHora) {
        this.entrenamiento = entrenamiento;
        this.jugador = jugador;
        this.fechaHora = fechaHora;
        this.estado = "PENDIENTE";
    }

    public void marcarPresente() {
        estado = "PRESENTE";
    }

    public void justificarAusencia() {
        estado = "AUSENCIA JUSTIFICADA";
    }

    public Entrenamiento getEntrenamiento() {
        return entrenamiento;
    }

    public PerfilJugador getJugador() {
        return jugador;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public String getEstado() {
        return estado;
    }
}
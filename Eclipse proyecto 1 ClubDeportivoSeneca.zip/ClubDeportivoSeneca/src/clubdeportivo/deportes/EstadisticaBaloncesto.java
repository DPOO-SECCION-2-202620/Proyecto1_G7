package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public class EstadisticaBaloncesto extends EstadisticaPartido {

    private int puntos;
    private int rebotes;

    public EstadisticaBaloncesto(
            Partido partido,
            PerfilJugador jugador) {
        super(partido, jugador);
    }

    public void registrarPuntos(int cantidad) {
        if (cantidad >= 0) {
            puntos += cantidad;
        }
    }

    public void registrarRebotes(int cantidad) {
        if (cantidad >= 0) {
            rebotes += cantidad;
        }
    }

    @Override
    public void actualizarEstadisticas() {
        // Los valores se actualizan al registrar cada evento.
    }

    public int getPuntos() {
        return puntos;
    }

    public int getRebotes() {
        return rebotes;
    }
}
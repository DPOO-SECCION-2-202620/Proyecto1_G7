package clubdeportivo.deportes;

public abstract class DeporteIndividual {

    private String nombre;

    public DeporteIndividual(String nombre) {
        this.nombre = nombre;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public abstract boolean validarModalidad();
}
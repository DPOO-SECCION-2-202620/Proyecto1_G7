package clubdeportivo.deportes;

import clubdeportivo.PerfilJugador;

public class RankingJugador {

    private PerfilJugador jugador;
    private double puntaje;
    private String disciplina;

    public RankingJugador(PerfilJugador jugador, String disciplina) {
        this.jugador = jugador;
        this.disciplina = disciplina;
        this.puntaje = 0;
    }

    public void actualizarPuntaje(double variacion) {
        if (puntaje + variacion >= 0) {
            puntaje += variacion;
        }
    }

    public PerfilJugador getJugador() {
        return jugador;
    }

    public double getPuntaje() {
        return puntaje;
    }

    public String getDisciplina() {
        return disciplina;
    }
}
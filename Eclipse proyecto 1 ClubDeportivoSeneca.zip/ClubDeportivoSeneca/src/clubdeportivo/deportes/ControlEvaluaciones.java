package clubdeportivo.deportes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import clubdeportivo.PerfilJugador;

public class ControlEvaluaciones {

    private final List<EvaluacionDesempeno> evaluaciones =
            new ArrayList<EvaluacionDesempeno>();

    public boolean registrar(
            EvaluacionDesempeno evaluacion,
            ControlEntrenamientos control) {

        if (evaluacion == null || control == null
                || !control.getEntrenamientos().contains(
                        evaluacion.getEntrenamiento())
                || evaluacion.getJugador() == null
                || evaluacion.getJugador().getUsuario() == null) {
            return false;
        }

        String login = evaluacion.getJugador()
                .getUsuario().getLogin();

        for (EvaluacionDesempeno actual : evaluaciones) {
            boolean mismoEntrenamiento =
                    actual.getEntrenamiento()
                            == evaluacion.getEntrenamiento();

            boolean mismoJugador = actual.getJugador()
                    .getUsuario().getLogin()
                    .equalsIgnoreCase(login);

            if (mismoEntrenamiento && mismoJugador) {
                return false;
            }
        }

        evaluaciones.add(evaluacion);
        return true;
    }

    public List<EvaluacionDesempeno> consultar(
            PerfilJugador jugador) {

        List<EvaluacionDesempeno> resultado =
                new ArrayList<EvaluacionDesempeno>();

        if (jugador == null || jugador.getUsuario() == null) {
            return resultado;
        }

        String login = jugador.getUsuario().getLogin();

        for (EvaluacionDesempeno evaluacion : evaluaciones) {
            if (evaluacion.getJugador().getUsuario()
                    .getLogin().equalsIgnoreCase(login)) {
                resultado.add(evaluacion);
            }
        }

        return Collections.unmodifiableList(resultado);
    }

    public double calcularPromedio(PerfilJugador jugador) {
        List<EvaluacionDesempeno> resultado = consultar(jugador);

        if (resultado.isEmpty()) {
            return 0;
        }

        int suma = 0;

        for (EvaluacionDesempeno evaluacion : resultado) {
            suma += evaluacion.getCalificacion();
        }

        return (double) suma / resultado.size();
    }
}
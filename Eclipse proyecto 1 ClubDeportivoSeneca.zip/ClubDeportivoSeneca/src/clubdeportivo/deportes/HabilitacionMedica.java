package clubdeportivo.deportes;

import java.time.LocalDate;
import clubdeportivo.PerfilJugador;

public class HabilitacionMedica {

    private final PerfilJugador jugador;
    private final LocalDate fechaEmision;
    private final LocalDate fechaVencimiento;
    private boolean activa;

    public HabilitacionMedica(
            PerfilJugador jugador,
            LocalDate fechaEmision,
            LocalDate fechaVencimiento) {

        if (jugador == null || fechaEmision == null
                || fechaVencimiento == null
                || fechaVencimiento.isBefore(fechaEmision)) {
            throw new IllegalArgumentException(
                    "Datos de habilitacion medica invalidos."
            );
        }

        this.jugador = jugador;
        this.fechaEmision = fechaEmision;
        this.fechaVencimiento = fechaVencimiento;
        this.activa = true;
    }

    public boolean estaVigente(LocalDate fecha) {
        return activa
                && fecha != null
                && !fecha.isBefore(fechaEmision)
                && !fecha.isAfter(fechaVencimiento);
    }

    public void revocar() {
        activa = false;
    }

    public PerfilJugador getJugador() {
        return jugador;
    }

    public LocalDate getFechaEmision() {
        return fechaEmision;
    }

    public LocalDate getFechaVencimiento() {
        return fechaVencimiento;
    }

    public boolean isActiva() {
        return activa;
    }
}
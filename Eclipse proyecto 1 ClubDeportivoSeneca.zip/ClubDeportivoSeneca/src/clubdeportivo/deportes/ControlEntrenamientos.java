package clubdeportivo.deportes;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import clubdeportivo.PerfilJugador;

public class ControlEntrenamientos {

    private final List<Entrenamiento> entrenamientos =
            new ArrayList<Entrenamiento>();

    private final List<RegistroAsistencia> registros =
            new ArrayList<RegistroAsistencia>();

    public boolean agregarEntrenamiento(Entrenamiento entrenamiento) {
        if (entrenamiento == null
                || !entrenamiento.validarHorario()
                || entrenamientos.contains(entrenamiento)) {
            return false;
        }

        entrenamientos.add(entrenamiento);
        return true;
    }

    public boolean marcarPresente(
            Entrenamiento entrenamiento,
            PerfilJugador jugador) {

        RegistroAsistencia registro =
                crearRegistroSiEsValido(entrenamiento, jugador);

        if (registro == null) {
            return false;
        }

        registro.marcarPresente();
        registros.add(registro);
        return true;
    }

    public boolean justificarAusencia(
            Entrenamiento entrenamiento,
            PerfilJugador jugador) {

        RegistroAsistencia registro =
                crearRegistroSiEsValido(entrenamiento, jugador);

        if (registro == null) {
            return false;
        }

        registro.justificarAusencia();
        registros.add(registro);
        return true;
    }

    public List<RegistroAsistencia> consultarAsistencias(
            PerfilJugador jugador) {

        List<RegistroAsistencia> resultado =
                new ArrayList<RegistroAsistencia>();

        if (jugador == null || jugador.getUsuario() == null) {
            return resultado;
        }

        String login = jugador.getUsuario().getLogin();

        for (RegistroAsistencia registro : registros) {
            String loginRegistro = registro.getJugador()
                    .getUsuario()
                    .getLogin();

            if (login.equalsIgnoreCase(loginRegistro)) {
                resultado.add(registro);
            }
        }

        return resultado;
    }

    public double porcentajeAsistencia(PerfilJugador jugador) {
        List<RegistroAsistencia> asistencias =
                consultarAsistencias(jugador);

        if (asistencias.isEmpty()) {
            return 0;
        }

        int presentes = 0;

        for (RegistroAsistencia registro : asistencias) {
            if ("PRESENTE".equalsIgnoreCase(registro.getEstado())) {
                presentes++;
            }
        }

        return presentes * 100.0 / asistencias.size();
    }

    public List<Entrenamiento> getEntrenamientos() {
        return Collections.unmodifiableList(entrenamientos);
    }

    public List<RegistroAsistencia> getRegistros() {
        return Collections.unmodifiableList(registros);
    }

    private RegistroAsistencia crearRegistroSiEsValido(
            Entrenamiento entrenamiento,
            PerfilJugador jugador) {

        if (entrenamiento == null || jugador == null
                || jugador.getUsuario() == null
                || !entrenamientos.contains(entrenamiento)) {
            return null;
        }

        String login = jugador.getUsuario().getLogin();

        for (RegistroAsistencia registro : registros) {
            boolean mismoEntrenamiento =
                    registro.getEntrenamiento() == entrenamiento;

            boolean mismoJugador = registro.getJugador()
                    .getUsuario()
                    .getLogin()
                    .equalsIgnoreCase(login);

            if (mismoEntrenamiento && mismoJugador) {
                return null;
            }
        }

        return new RegistroAsistencia(
                entrenamiento,
                jugador,
                LocalDateTime.now()
        );
    }
}
package clubdeportivo.deportes;

import java.time.LocalDateTime;
import clubdeportivo.Equipo;

public class Entrenamiento {

    private LocalDateTime fechaHora;
    private int duracionMinutos;
    private String tipo;
    private Equipo equipo;
    private PlanEntrenamiento plan;

    public Entrenamiento(LocalDateTime fechaHora,
            int duracionMinutos, String tipo,
            Equipo equipo, PlanEntrenamiento plan) {
        this.fechaHora = fechaHora;
        this.duracionMinutos = duracionMinutos;
        this.tipo = tipo;
        this.equipo = equipo;
        this.plan = plan;
    }

    public boolean validarHorario() {
        return fechaHora != null
                && duracionMinutos > 0
                && equipo != null;
    }

    public boolean registrarAsistencia() {
        return validarHorario();
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    public String getTipo() {
        return tipo;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public PlanEntrenamiento getPlan() {
        return plan;
    }
}
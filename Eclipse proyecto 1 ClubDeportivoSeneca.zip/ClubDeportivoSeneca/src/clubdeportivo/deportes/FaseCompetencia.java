package clubdeportivo.deportes;

import java.util.ArrayList;
import java.util.List;

public class FaseCompetencia {

    private String tipoFase;
    private List<GrupoCompetencia> grupos;

    public FaseCompetencia(String tipoFase) {
        this.tipoFase = tipoFase;
        this.grupos = new ArrayList<GrupoCompetencia>();
    }

    public void agregarGrupo(GrupoCompetencia grupo) {
        if (grupo != null && !grupos.contains(grupo)) {
            grupos.add(grupo);
        }
    }

    public List<String> calcularPosiciones() {
        List<String> resultado = new ArrayList<String>();

        for (GrupoCompetencia grupo : grupos) {
            resultado.addAll(grupo.calcularPosiciones());
        }

        return resultado;
    }

    public void avanzarEquipos() {
        calcularPosiciones();
    }

    public String getTipoFase() {
        return tipoFase;
    }

    public List<GrupoCompetencia> getGrupos() {
        return new ArrayList<GrupoCompetencia>(grupos);
    }
}
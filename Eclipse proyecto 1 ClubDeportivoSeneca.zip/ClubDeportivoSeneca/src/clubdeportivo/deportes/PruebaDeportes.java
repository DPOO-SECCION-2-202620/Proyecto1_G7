package clubdeportivo.deportes;

import java.time.LocalDate;
import clubdeportivo.CategoriaEdad;
import clubdeportivo.DeporteConjunto;
import clubdeportivo.Equipo;
import clubdeportivo.PerfilJugador;
import clubdeportivo.Socio;

public class PruebaDeportes {

    public static void main(String[] args) {
        DeporteConjunto futbol =
                new DeporteConjunto("Futbol", 7);
        CategoriaEdad sub17 =
                new CategoriaEdad("Sub-17");

        Equipo local = new Equipo(
                "Seneca Juvenil",
                18,
                futbol,
                sub17
        );

        Equipo visitante = new Equipo(
                "Equipo Visitante",
                18,
                futbol,
                sub17
        );

        PartidoInterno partido = new PartidoInterno(
                "P-001",
                LocalDate.now(),
                local,
                visitante
        );

        System.out.println(
                "Partido valido: " + partido.puedeDisputarse()
        );

        System.out.println(
                "Resultado registrado: "
                        + partido.registrarResultado(2, 1)
        );

        System.out.println("Marcador: " + partido.obtenerResultado());

        Socio socio = new Socio("socio01", "clave123", 16);
        PerfilJugador jugador = new PerfilJugador(socio);

        EstadisticaFutbol estadistica =
                new EstadisticaFutbol(partido, jugador);

        estadistica.registrarGoles(1);
        estadistica.registrarAsistencias(1);
        estadistica.registrarTarjetaAmarilla();

        System.out.println("Goles: " + estadistica.getGoles());
        System.out.println(
                "Asistencias: " + estadistica.getAsistencias()
        );
        System.out.println(
                "Amarillas: " + estadistica.getTarjetasAmarillas()
        );

        Sancion sancion = new Sancion(
                jugador,
                "Acumulacion de tarjetas",
                2
        );

        sancion.aplicarSuspension();
        System.out.println(
                "Partidos de sancion pendientes: "
                        + sancion.getPartidosPendientes()
        );
    }
}
package clubdeportivo;

public class Equipo {

    private String nombreEquipo;
    private int cupoMax;
    private DeporteConjunto deporte;
    private Categoria categoria;

    public Equipo(
            String nombreEquipo,
            int cupoMax,
            DeporteConjunto deporte,
            Categoria categoria) {
        this.nombreEquipo = nombreEquipo;
        this.cupoMax = cupoMax;
        this.deporte = deporte;
        this.categoria = categoria;
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public int getCupoMax() {
        return cupoMax;
    }

    public DeporteConjunto getDeporte() {
        return deporte;
    }

    public Categoria getCategoria() {
        return categoria;
    }
}
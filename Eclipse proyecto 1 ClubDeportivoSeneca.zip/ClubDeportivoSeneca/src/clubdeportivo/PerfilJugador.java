package clubdeportivo;

public class PerfilJugador {

    private Usuario usuario;

    public PerfilJugador(Usuario usuario) {
        this.usuario = usuario;
    }

    public Usuario getUsuario() {
        return usuario;
    }
}
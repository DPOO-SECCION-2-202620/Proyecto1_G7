package clubdeportivo;

import java.util.ArrayList;

public class ClubDeportivo {

    private ArrayList<Socio> socios;
    private ArrayList<Equipo> equipos;
    private ArrayList<InscripcionEquipo> inscripcionesEquipo;

    public ClubDeportivo() {
        socios = new ArrayList<Socio>();
        equipos = new ArrayList<Equipo>();
        inscripcionesEquipo = new ArrayList<InscripcionEquipo>();
    }

    public void agregarSocio(Socio socio) {
        socios.add(socio);
    }

    public void agregarEquipo(Equipo equipo) {
        equipos.add(equipo);
    }

    public Socio iniciarSesionSocio(String login, String contrasena) {
        for (Socio socio : socios) {
            if (socio.getLogin().equals(login)
                    && socio.getContrasena().equals(contrasena)) {
                return socio;
            }
        }

        return null;
    }

    public boolean agregarInscripcionEquipo(InscripcionEquipo inscripcion) {
        Equipo equipo = inscripcion.getEquipo();

        if (!hayCupoPara(equipo)) {
            return false;
        }

        if (!numeroCamisetaDisponible(
                equipo, inscripcion.getNumeroCamiseta())) {
            return false;
        }

        if (jugadorYaInscritoEnDeporte(
                inscripcion.getJugador(), equipo.getDeporte())) {
            return false;
        }

        if (!edadCompatible(
                inscripcion.getJugador(), equipo.getCategoria())) {
            return false;
        }

        inscripcionesEquipo.add(inscripcion);
        return true;
    }

    public ArrayList<Socio> getSocios() {
        return socios;
    }

    public ArrayList<Equipo> getEquipos() {
        return equipos;
    }

    public ArrayList<InscripcionEquipo> getInscripcionesEquipo() {
        return inscripcionesEquipo;
    }

    public ArrayList<InscripcionEquipo> consultarInscripcionesDe(Socio socio) {
        ArrayList<InscripcionEquipo> resultado =
                new ArrayList<InscripcionEquipo>();

        for (InscripcionEquipo inscripcion : inscripcionesEquipo) {
            String loginJugador = inscripcion.getJugador()
                    .getUsuario()
                    .getLogin();

            if (loginJugador.equalsIgnoreCase(socio.getLogin())) {
                resultado.add(inscripcion);
            }
        }

        return resultado;
    }

    public boolean hayCupoPara(Equipo equipo) {
        int cantidadInscritos = 0;

        for (InscripcionEquipo inscripcion : inscripcionesEquipo) {
            if (inscripcion.getEquipo() == equipo) {
                cantidadInscritos++;
            }
        }

        return cantidadInscritos < equipo.getCupoMax();
    }

    public boolean numeroCamisetaDisponible(Equipo equipo, int numero) {
        for (InscripcionEquipo inscripcion : inscripcionesEquipo) {
            if (inscripcion.getEquipo() == equipo
                    && inscripcion.getNumeroCamiseta() == numero) {
                return false;
            }
        }

        return true;
    }

    private boolean jugadorYaInscritoEnDeporte(
            PerfilJugador jugador,
            DeporteConjunto deporte) {

        for (InscripcionEquipo existente : inscripcionesEquipo) {
            boolean mismoJugador = existente.getJugador()
                    .getUsuario()
                    .getLogin()
                    .equalsIgnoreCase(jugador.getUsuario().getLogin());

            boolean mismoDeporte = existente.getEquipo()
                    .getDeporte()
                    .getNombre()
                    .equalsIgnoreCase(deporte.getNombre());

            if (mismoJugador && mismoDeporte) {
                return true;
            }
        }

        return false;
    }

    private boolean edadCompatible(
            PerfilJugador jugador,
            Categoria categoria) {

        if (!(categoria instanceof CategoriaEdad)) {
            return false;
        }

        if (!(jugador.getUsuario() instanceof Socio)) {
            return false;
        }

        Socio socio = (Socio) jugador.getUsuario();
        CategoriaEdad categoriaEdad = (CategoriaEdad) categoria;
        int edad = socio.getEdad();
        String nombre = categoriaEdad.getNombreCategoria();

        if (nombre.equalsIgnoreCase("Sub-13")) {
            return edad < 13;
        }

        if (nombre.equalsIgnoreCase("Sub-15")) {
            return edad >= 13 && edad < 15;
        }

        if (nombre.equalsIgnoreCase("Sub-17")) {
            return edad >= 15 && edad < 17;
        }

        if (nombre.equalsIgnoreCase("Mayores")) {
            return edad >= 17;
        }

        return false;
    }
}
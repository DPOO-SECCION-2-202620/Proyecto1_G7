package clubdeportivo;

public class Socio extends Usuario {

    private int edad;

    public Socio(String login, String contrasena, int edad) {
        super(login, contrasena);
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }
}
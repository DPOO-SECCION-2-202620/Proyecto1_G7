package clubdeportivo;

public class Categoria {
}
package clubdeportivo.operaciones;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Caja implements Serializable {

    private static final long serialVersionUID = 1L;

    private final Inventario inventario;
    private final ReglaVenta reglas;
    private final List<Venta> ventas;

    public Caja(Inventario inventario) {
        if (inventario == null) {
            throw new IllegalArgumentException("El inventario es obligatorio.");
        }

        this.inventario = inventario;
        this.reglas = new ReglaVenta();
        this.ventas = new ArrayList<Venta>();
    }

    public Venta registrarVenta(
            String id,
            String tipo,
            List<DetalleVenta> detalles,
            Instalacion instalacion,
            CuentaFidelidad cuenta,
            boolean incluirPropina) {

        if (id == null || id.isBlank()
                || tipo == null
                || detalles == null || detalles.isEmpty()
                || buscarVenta(id) != null) {
            return null;
        }

        String tipoNormalizado = tipo.toUpperCase();

        if (!tipoNormalizado.equals("TIENDA")
                && !tipoNormalizado.equals("CAFETERIA")) {
            return null;
        }

        Map<String, Integer> cantidades =
                new LinkedHashMap<String, Integer>();
        double subtotal = 0;

        for (DetalleVenta detalle : detalles) {
            if (detalle == null || detalle.getProducto() == null) {
                return null;
            }

            Producto producto = detalle.getProducto();
            Producto delInventario =
                    inventario.buscarProducto(producto.getCodigo());

            if (delInventario != producto
                    || !producto.getTipo().equalsIgnoreCase(tipoNormalizado)) {
                return null;
            }

            if (producto instanceof Bebida) {
                Bebida bebida = (Bebida) producto;

                if (!reglas.validarBebidaCaliente(bebida, instalacion)) {
                    return null;
                }
            }

            String codigo = producto.getCodigo();
            int cantidad = cantidades.getOrDefault(codigo, 0)
                    + detalle.getCantidad();

            cantidades.put(codigo, cantidad);
            subtotal += detalle.calcularSubtotal();
        }

        for (Map.Entry<String, Integer> entrada : cantidades.entrySet()) {
            Producto producto = inventario.buscarProducto(entrada.getKey());

            if (producto == null
                    || !producto.hayExistencias(entrada.getValue())) {
                return null;
            }
        }

        double impuesto =
                reglas.calcularImpuesto(tipoNormalizado, subtotal);

        double propina = 0;
        if (tipoNormalizado.equals("CAFETERIA") && incluirPropina) {
            propina = reglas.calcularPropina(
                    subtotal,
                    ReglaVenta.PROPINA_SUGERIDA
            );
        }

        Venta venta = new Venta(
                id,
                tipoNormalizado,
                detalles,
                impuesto,
                propina
        );

        List<String> actualizados = new ArrayList<String>();

        for (Map.Entry<String, Integer> entrada : cantidades.entrySet()) {
            boolean correcto = inventario.actualizarExistencias(
                    entrada.getKey(),
                    -entrada.getValue()
            );

            if (!correcto) {
                for (String codigo : actualizados) {
                    inventario.actualizarExistencias(
                            codigo,
                            cantidades.get(codigo)
                    );
                }
                return null;
            }

            actualizados.add(entrada.getKey());
        }

        if (cuenta != null) {
            cuenta.acumularPuntos(subtotal);
        }

        ventas.add(venta);
        return venta;
    }

    public Venta buscarVenta(String id) {
        for (Venta venta : ventas) {
            if (venta.getId().equalsIgnoreCase(id)) {
                return venta;
            }
        }

        return null;
    }

    public List<Venta> getVentas() {
        return Collections.unmodifiableList(ventas);
    }

    public Inventario getInventario() {
        return inventario;
    }
}
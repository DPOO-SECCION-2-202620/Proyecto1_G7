package clubdeportivo.operaciones;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Venta implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String id;
    private final String tipo;
    private final LocalDateTime fechaHora;
    private final List<DetalleVenta> detalles;
    private final double subtotal;
    private final double impuesto;
    private final double propina;

    public Venta(
            String id,
            String tipo,
            List<DetalleVenta> detalles,
            double impuesto,
            double propina) {

        if (id == null || id.isBlank()
                || tipo == null
                || detalles == null || detalles.isEmpty()
                || impuesto < 0 || propina < 0) {
            throw new IllegalArgumentException("Datos de venta invalidos.");
        }

        this.id = id;
        this.tipo = tipo.toUpperCase();
        this.fechaHora = LocalDateTime.now();
        this.detalles = new ArrayList<DetalleVenta>(detalles);
        this.impuesto = impuesto;
        this.propina = propina;

        double suma = 0;
        for (DetalleVenta detalle : detalles) {
            suma += detalle.calcularSubtotal();
        }
        this.subtotal = suma;
    }

    public double calcularTotal() {
        return subtotal + impuesto + propina;
    }

    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public List<DetalleVenta> getDetalles() {
        return Collections.unmodifiableList(detalles);
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public double getPropina() {
        return propina;
    }
}
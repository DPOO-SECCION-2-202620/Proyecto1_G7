package clubdeportivo.operaciones;

import java.util.ArrayList;
import java.util.List;

public class PruebaOperaciones {

    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        Producto balon = new Producto(
                "BAL01",
                "Balon",
                50000,
                5,
                "TIENDA"
        );

        inventario.agregarProducto(balon);

        Caja caja = new Caja(inventario);
        CuentaFidelidad cuenta = new CuentaFidelidad();

        List<DetalleVenta> detalles = new ArrayList<DetalleVenta>();
        detalles.add(new DetalleVenta(balon, 2));

        Venta venta = caja.registrarVenta(
                "V-001",
                "TIENDA",
                detalles,
                null,
                cuenta,
                false
        );

        if (venta == null) {
            System.out.println("La venta fue rechazada.");
            return;
        }

        System.out.println("Venta: " + venta.getId());
        System.out.println("Subtotal: " + venta.getSubtotal());
        System.out.println("Impuesto: " + venta.getImpuesto());
        System.out.println("Total: " + venta.calcularTotal());
        System.out.println(
                "Existencias restantes: "
                        + inventario.consultarExistencias("BAL01")
        );
        System.out.println("Puntos acumulados: " + cuenta.consultarSaldo());
    }
}
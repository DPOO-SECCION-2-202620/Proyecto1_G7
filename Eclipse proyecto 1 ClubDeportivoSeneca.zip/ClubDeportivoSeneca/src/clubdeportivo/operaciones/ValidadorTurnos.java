package clubdeportivo.operaciones;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ValidadorTurnos {

    public boolean coberturaMinimaCumplida(
            List<Turno> turnos,
            LocalDate fecha,
            LocalTime apertura,
            LocalTime cierre) {

        if (turnos == null || fecha == null
                || apertura == null || cierre == null
                || !cierre.isAfter(apertura)) {
            return false;
        }

        Set<LocalTime> limites = new TreeSet<LocalTime>();
        limites.add(apertura);
        limites.add(cierre);

        for (Turno turno : turnos) {
            if (turno == null || !fecha.equals(turno.getFecha())
                    || turno.getEmpleadoId() == null) {
                continue;
            }

            LocalTime inicio = turno.getHoraInicio().isAfter(apertura)
                    ? turno.getHoraInicio() : apertura;
            LocalTime fin = turno.getHoraFin().isBefore(cierre)
                    ? turno.getHoraFin() : cierre;

            if (fin.isAfter(inicio)) {
                limites.add(inicio);
                limites.add(fin);
            }
        }

        LocalTime[] puntos = limites.toArray(new LocalTime[0]);

        for (int i = 0; i < puntos.length - 1; i++) {
            LocalTime inicioTramo = puntos[i];
            LocalTime finTramo = puntos[i + 1];

            Set<String> entrenadores = new TreeSet<String>();
            Set<String> fisioterapeutas = new TreeSet<String>();

            for (Turno turno : turnos) {
                if (turno == null || !fecha.equals(turno.getFecha())
                        || turno.getEmpleadoId() == null
                        || turno.getRolEmpleado() == null) {
                    continue;
                }

                boolean cubreTramo =
                        !turno.getHoraInicio().isAfter(inicioTramo)
                        && !turno.getHoraFin().isBefore(finTramo);

                if (!cubreTramo) {
                    continue;
                }

                String rol = turno.getRolEmpleado().toUpperCase();
                String empleado = turno.getEmpleadoId();

                if (rol.contains("ENTRENADOR")) {
                    entrenadores.add(empleado);
                }

                if (rol.contains("FISIOTERAPEUTA")
                        || rol.contains("FISIOTERAPISTA")) {
                    fisioterapeutas.add(empleado);
                }
            }

            if (entrenadores.size() < 2
                    || fisioterapeutas.size() < 1) {
                return false;
            }
        }

        return true;
    }
}
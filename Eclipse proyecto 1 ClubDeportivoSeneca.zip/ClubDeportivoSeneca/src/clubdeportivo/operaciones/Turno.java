package clubdeportivo.operaciones;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class Turno implements Serializable {
    private static final long serialVersionUID = 1L;

    private final LocalDate fecha;
    private final LocalTime horaInicio;
    private final LocalTime horaFin;
    private String estado = "DISPONIBLE";
    private String empleadoId;
    private String rolEmpleado;

    public Turno(LocalDate fecha, LocalTime inicio, LocalTime fin) {
        if (fecha == null || inicio == null || fin == null
                || !fin.isAfter(inicio)) {
            throw new IllegalArgumentException("Horario inválido");
        }

        this.fecha = fecha;
        this.horaInicio = inicio;
        this.horaFin = fin;
    }

    public boolean estaDisponible() {
        return "DISPONIBLE".equals(estado);
    }

    public boolean asignarEmpleado(String id, String rol) {
        if (!estaDisponible() || id == null || id.isBlank()
                || rol == null || rol.isBlank()) {
            return false;
        }

        empleadoId = id;
        rolEmpleado = rol;
        estado = "ASIGNADO";
        return true;
    }

    public boolean cambiarEstado(String nuevoEstado) {
        if (nuevoEstado == null || nuevoEstado.isBlank()) {
            return false;
        }

        estado = nuevoEstado.toUpperCase();
        return true;
    }

    public LocalDate getFecha() { return fecha; }
    public LocalTime getHoraInicio() { return horaInicio; }
    public LocalTime getHoraFin() { return horaFin; }
    public String getEstado() { return estado; }
    public String getEmpleadoId() { return empleadoId; }
    public String getRolEmpleado() { return rolEmpleado; }
    public boolean reemplazarEmpleado(String id, String rol) {
        if (!"ASIGNADO".equalsIgnoreCase(estado)
                || id == null || id.isBlank()
                || rol == null || rol.isBlank()) {
            return false;
        }

        empleadoId = id;
        rolEmpleado = rol;
        return true;
    }
}
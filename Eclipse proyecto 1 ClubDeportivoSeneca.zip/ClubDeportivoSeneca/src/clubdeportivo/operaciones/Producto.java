package clubdeportivo.operaciones;

import java.io.Serializable;

public class Producto implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String codigo;
    private String nombre;
    private double precioBase;
    private int cantidadDisponible;
    private final String tipo;

    public Producto(String codigo, String nombre, double precioBase,
                    int cantidadDisponible, String tipo) {
        if (codigo == null || codigo.isBlank()
                || nombre == null || nombre.isBlank()
                || precioBase < 0 || cantidadDisponible < 0) {
            throw new IllegalArgumentException("Datos inválidos");
        }

        this.codigo = codigo;
        this.nombre = nombre;
        this.precioBase = precioBase;
        this.cantidadDisponible = cantidadDisponible;
        this.tipo = tipo == null ? "TIENDA" : tipo.toUpperCase();
    }

    public boolean hayExistencias(int cantidad) {
        return cantidad > 0 && cantidadDisponible >= cantidad;
    }

    public boolean actualizarExistencias(int variacion) {
        if (cantidadDisponible + variacion < 0) {
            return false;
        }

        cantidadDisponible += variacion;
        return true;
    }

    public void actualizarPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("Precio inválido");
        }
        precioBase = precio;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getTipo() { return tipo; }
    public double getPrecioBase() { return precioBase; }
    public int getCantidadDisponible() { return cantidadDisponible; }
}
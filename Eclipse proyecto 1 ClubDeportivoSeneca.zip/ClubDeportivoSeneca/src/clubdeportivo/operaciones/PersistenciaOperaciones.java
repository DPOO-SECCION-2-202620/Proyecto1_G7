package clubdeportivo.operaciones;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PersistenciaOperaciones {

    private final PersistenciaClub persistencia;

    public PersistenciaOperaciones(String carpetaDatos) {
        persistencia = new PersistenciaClub(carpetaDatos);
    }

    public void guardar(
            Inventario inventario,
            Caja caja,
            List<Turno> turnos,
            List<Instalacion> instalaciones) throws IOException {

        if (inventario == null || caja == null
                || turnos == null || instalaciones == null) {
            throw new IllegalArgumentException(
                    "Faltan datos de operaciones."
            );
        }

        DatosOperaciones datos = new DatosOperaciones(
                inventario,
                caja,
                turnos,
                instalaciones
        );

        persistencia.guardarObjeto("operaciones", datos);
    }

    public DatosOperaciones cargar()
            throws IOException, ClassNotFoundException {

        Object objeto = persistencia.cargarObjeto("operaciones");

        if (objeto == null) {
            return null;
        }

        if (!(objeto instanceof DatosOperaciones)) {
            throw new IOException("El archivo tiene un formato inesperado.");
        }

        return (DatosOperaciones) objeto;
    }

    public static class DatosOperaciones implements Serializable {

        private static final long serialVersionUID = 1L;

        private final Inventario inventario;
        private final Caja caja;
        private final List<Turno> turnos;
        private final List<Instalacion> instalaciones;

        public DatosOperaciones(
                Inventario inventario,
                Caja caja,
                List<Turno> turnos,
                List<Instalacion> instalaciones) {

            this.inventario = inventario;
            this.caja = caja;
            this.turnos = new ArrayList<Turno>(turnos);
            this.instalaciones =
                    new ArrayList<Instalacion>(instalaciones);
        }

        public Inventario getInventario() {
            return inventario;
        }

        public Caja getCaja() {
            return caja;
        }

        public List<Turno> getTurnos() {
            return Collections.unmodifiableList(turnos);
        }

        public List<Instalacion> getInstalaciones() {
            return Collections.unmodifiableList(instalaciones);
        }
    }
}
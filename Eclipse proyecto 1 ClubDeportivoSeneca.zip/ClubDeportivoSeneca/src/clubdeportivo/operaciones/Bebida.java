package clubdeportivo.operaciones;

public class Bebida extends Producto {
    private static final long serialVersionUID = 1L;

    private final boolean caliente;
    private final double volumenLitros;

    public Bebida(String codigo, String nombre, double precio,
                  int cantidad, boolean caliente, double volumenLitros) {
        super(codigo, nombre, precio, cantidad, "CAFETERIA");

        if (volumenLitros <= 0) {
            throw new IllegalArgumentException("Volumen inválido");
        }

        this.caliente = caliente;
        this.volumenLitros = volumenLitros;
    }

    public boolean esCaliente() { return caliente; }
    public double getVolumenLitros() { return volumenLitros; }
}
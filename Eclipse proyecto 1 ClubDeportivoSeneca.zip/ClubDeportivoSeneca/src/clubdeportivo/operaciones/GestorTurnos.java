package clubdeportivo.operaciones;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class GestorTurnos {

    private final ValidadorTurnos validador = new ValidadorTurnos();

    public boolean solicitarCambio(
            Turno turno,
            String nuevoEmpleadoId,
            String nuevoRol,
            List<Turno> agenda,
            LocalDate fecha,
            LocalTime apertura,
            LocalTime cierre) {

        if (turno == null || nuevoEmpleadoId == null
                || nuevoEmpleadoId.isBlank()
                || nuevoRol == null || nuevoRol.isBlank()
                || agenda == null || !agenda.contains(turno)
                || turno.getEmpleadoId() == null) {
            return false;
        }

        List<Turno> propuesta = new ArrayList<Turno>();

        for (Turno actual : agenda) {
            Turno copia = copiarTurno(actual);

            if (actual == turno
                    && !copia.reemplazarEmpleado(
                            nuevoEmpleadoId,
                            nuevoRol)) {
                return false;
            }

            propuesta.add(copia);
        }

        if (!validador.coberturaMinimaCumplida(
                propuesta, fecha, apertura, cierre)) {
            return false;
        }

        return turno.reemplazarEmpleado(nuevoEmpleadoId, nuevoRol);
    }

    private Turno copiarTurno(Turno original) {
        Turno copia = new Turno(
                original.getFecha(),
                original.getHoraInicio(),
                original.getHoraFin()
        );

        if (original.getEmpleadoId() != null
                && original.getRolEmpleado() != null) {
            copia.asignarEmpleado(
                    original.getEmpleadoId(),
                    original.getRolEmpleado()
            );
        }

        return copia;
    }
}
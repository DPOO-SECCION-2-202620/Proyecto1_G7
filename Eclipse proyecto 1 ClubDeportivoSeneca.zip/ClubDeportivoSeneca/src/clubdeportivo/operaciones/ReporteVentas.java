package clubdeportivo.operaciones;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

public class ReporteVentas {

    public Map<String, Double> ventasPorRubro(
            Caja caja,
            LocalDate desde,
            LocalDate hasta) {

        if (caja == null || desde == null || hasta == null
                || hasta.isBefore(desde)) {
            throw new IllegalArgumentException("Fechas o caja invalidas.");
        }

        Map<String, Double> totales =
                new LinkedHashMap<String, Double>();

        totales.put("TIENDA", 0.0);
        totales.put("CAFETERIA", 0.0);

        for (Venta venta : caja.getVentas()) {
            LocalDate fechaVenta = venta.getFechaHora().toLocalDate();

            boolean dentroDelPeriodo =
                    !fechaVenta.isBefore(desde)
                    && !fechaVenta.isAfter(hasta);

            if (dentroDelPeriodo) {
                String rubro = venta.getTipo();
                double totalActual = totales.getOrDefault(rubro, 0.0);

                totales.put(
                        rubro,
                        totalActual + venta.calcularTotal()
                );
            }
        }

        return totales;
    }

    public double totalDelPeriodo(
            Caja caja,
            LocalDate desde,
            LocalDate hasta) {

        Map<String, Double> porRubro =
                ventasPorRubro(caja, desde, hasta);

        double total = 0;

        for (double valor : porRubro.values()) {
            total += valor;
        }

        return total;
    }
}
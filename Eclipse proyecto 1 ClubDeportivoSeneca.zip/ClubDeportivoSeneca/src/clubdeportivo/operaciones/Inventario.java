package clubdeportivo.operaciones;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Collections;

public class Inventario implements Serializable {
    private static final long serialVersionUID = 1L;

    private final Map<String, Producto> productos = new LinkedHashMap<>();

    public boolean agregarProducto(Producto producto) {
        if (producto == null
                || productos.containsKey(producto.getCodigo())) {
            return false;
        }

        productos.put(producto.getCodigo(), producto);
        return true;
    }

    public boolean actualizarExistencias(String codigo, int cantidad) {
        Producto producto = productos.get(codigo);

        return producto != null
                && producto.actualizarExistencias(cantidad);
    }

    public int consultarExistencias(String codigo) {
        Producto producto = productos.get(codigo);
        return producto == null ? 0 : producto.getCantidadDisponible();
    }

    public Producto buscarProducto(String codigo) {
        return productos.get(codigo);
    }

    public Map<String, Producto> getProductos() {
        return Collections.unmodifiableMap(productos);
    }
}
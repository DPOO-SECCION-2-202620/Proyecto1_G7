package clubdeportivo.operaciones;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Collections;

public class Snack extends Producto {
    private static final long serialVersionUID = 1L;

    private final Set<String> alergenos = new LinkedHashSet<>();
    private final String descripcion;

    public Snack(String codigo, String nombre, double precio,
                 int cantidad, String descripcion, Set<String> alergenos) {
        super(codigo, nombre, precio, cantidad, "CAFETERIA");

        this.descripcion = descripcion == null ? "" : descripcion;

        if (alergenos != null) {
            for (String alergeno : alergenos) {
                if (alergeno != null && !alergeno.isBlank()) {
                    this.alergenos.add(alergeno.trim().toLowerCase());
                }
            }
        }
    }

    public boolean contieneAlergeno(String alergeno) {
        return alergeno != null
                && alergenos.contains(alergeno.trim().toLowerCase());
    }

    public Set<String> getAlergenos() {
        return Collections.unmodifiableSet(alergenos);
    }

    public String getDescripcion() { return descripcion; }
}
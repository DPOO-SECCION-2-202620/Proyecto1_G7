package clubdeportivo.operaciones;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import clubdeportivo.PerfilJugador;
import clubdeportivo.Socio;
import clubdeportivo.deportes.ControlHabilitacionesMedicas;
import clubdeportivo.deportes.HabilitacionMedica;

public class PruebaIntegracion {

    public static void main(String[] args) throws Exception {
        // Venta e inventario
        Inventario inventario = new Inventario();
        Producto balon = new Producto(
                "BAL01", "Balon", 50000, 5, "TIENDA"
        );
        inventario.agregarProducto(balon);

        Caja caja = new Caja(inventario);
        CuentaFidelidad cuenta = new CuentaFidelidad();

        List<DetalleVenta> detalles = new ArrayList<DetalleVenta>();
        detalles.add(new DetalleVenta(balon, 2));

        Venta venta = caja.registrarVenta(
                "V-001", "TIENDA", detalles, null, cuenta, false
        );

        verificar(venta != null, "Venta registrada");
        verificar(
                inventario.consultarExistencias("BAL01") == 3,
                "Inventario descontado"
        );
        verificar(cuenta.consultarSaldo() == 2000, "Puntos acumulados");

        // Reserva y conflicto de horario
        Instalacion cancha = new Instalacion(
                "Cancha 1", "Deportiva", 20, "DISPONIBLE", false
        );
        GestorReservas gestorReservas = new GestorReservas();

        boolean reserva = gestorReservas.reservar(
                "R-001",
                cancha,
                LocalDateTime.of(2026, 10, 20, 9, 0),
                LocalDateTime.of(2026, 10, 20, 10, 0)
        );

        boolean conflicto = gestorReservas.reservar(
                "R-002",
                cancha,
                LocalDateTime.of(2026, 10, 20, 9, 30),
                LocalDateTime.of(2026, 10, 20, 10, 30)
        );

        verificar(reserva, "Primera reserva aceptada");
        verificar(!conflicto, "Cruce de horario rechazado");

        // Cobertura de turnos
        LocalDate fecha = LocalDate.now();
        List<Turno> turnos = new ArrayList<Turno>();

        Turno entrenador1 = crearTurno(fecha, "E01", "ENTRENADOR");
        Turno entrenador2 = crearTurno(fecha, "E02", "ENTRENADOR");
        Turno fisioterapeuta = crearTurno(
                fecha, "F01", "FISIOTERAPEUTA"
        );

        turnos.add(entrenador1);
        turnos.add(entrenador2);
        turnos.add(fisioterapeuta);

        ValidadorTurnos validador = new ValidadorTurnos();

        boolean cobertura = validador.coberturaMinimaCumplida(
                turnos,
                fecha,
                LocalTime.of(8, 0),
                LocalTime.of(16, 0)
        );

        verificar(cobertura, "Cobertura minima de turnos");

        // Vigencia médica
        Socio socio = new Socio("socio01", "clave123", 16);
        PerfilJugador jugador = new PerfilJugador(socio);

        ControlHabilitacionesMedicas controlMedico =
                new ControlHabilitacionesMedicas();

        HabilitacionMedica habilitacion = new HabilitacionMedica(
                jugador,
                fecha.minusDays(1),
                fecha.plusDays(30)
        );

        controlMedico.registrar(habilitacion);

        verificar(
                controlMedico.estaHabilitado(jugador, fecha),
                "Habilitacion medica vigente"
        );

        System.out.println("Pruebas de integracion completadas.");
    }

    private static Turno crearTurno(
            LocalDate fecha,
            String empleadoId,
            String rol) {

        Turno turno = new Turno(
                fecha,
                LocalTime.of(8, 0),
                LocalTime.of(16, 0)
        );

        turno.asignarEmpleado(empleadoId, rol);
        return turno;
    }

    private static void verificar(boolean correcto, String prueba) {
        if (!correcto) {
            throw new IllegalStateException("Fallo: " + prueba);
        }

        System.out.println("OK: " + prueba);
    }
}
package clubdeportivo.operaciones;

import java.io.Serializable;
import java.time.LocalDateTime;

public class ReservaInstalacion implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String id;
    private final Instalacion instalacion;
    private final LocalDateTime inicio;
    private final LocalDateTime fin;
    private String estado;

    public ReservaInstalacion(
            String id,
            Instalacion instalacion,
            LocalDateTime inicio,
            LocalDateTime fin,
            String estado) {

        if (id == null || id.isBlank()
                || instalacion == null
                || inicio == null || fin == null
                || !fin.isAfter(inicio)) {
            throw new IllegalArgumentException("Reserva invalida.");
        }

        this.id = id;
        this.instalacion = instalacion;
        this.inicio = inicio;
        this.fin = fin;
        this.estado = estado == null ? "CONFIRMADA" : estado;
    }

    public void cancelar() {
        estado = "CANCELADA";
    }

    public String getId() {
        return id;
    }

    public Instalacion getInstalacion() {
        return instalacion;
    }

    public LocalDateTime getInicio() {
        return inicio;
    }

    public LocalDateTime getFin() {
        return fin;
    }

    public String getEstado() {
        return estado;
    }
}
package clubdeportivo.operaciones;

import java.io.Serializable;

public class CuentaFidelidad implements Serializable {
    private static final long serialVersionUID = 1L;

    private int saldoPuntos;

    public CuentaFidelidad() {
        this(0);
    }

    public CuentaFidelidad(int saldoInicial) {
        if (saldoInicial < 0) {
            throw new IllegalArgumentException("Saldo inválido");
        }

        saldoPuntos = saldoInicial;
    }

    public void acumularPuntos(double valorCompra) {
        if (valorCompra < 0) {
            throw new IllegalArgumentException("Compra inválida");
        }

        saldoPuntos += (int) Math.floor(
                valorCompra * ReglaVenta.PORCENTAJE_PUNTOS);
    }

    public boolean redimirPuntos(int puntos) {
        if (puntos <= 0 || puntos > saldoPuntos) {
            return false;
        }

        saldoPuntos -= puntos;
        return true;
    }

    public int consultarSaldo() {
        return saldoPuntos;
    }
}
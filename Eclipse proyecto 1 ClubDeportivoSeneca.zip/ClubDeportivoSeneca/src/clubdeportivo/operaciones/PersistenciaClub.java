package clubdeportivo.operaciones;

import java.io.*;
import java.nio.file.*;

public class PersistenciaClub {
    private final Path carpetaDatos;

    public PersistenciaClub(String rutaCarpeta) {
        if (rutaCarpeta == null || rutaCarpeta.isBlank()) {
            throw new IllegalArgumentException("Ruta obligatoria");
        }

        carpetaDatos = Paths.get(rutaCarpeta)
                .toAbsolutePath().normalize();
    }

    public void guardarObjeto(String nombre, Object objeto)
            throws IOException {
        validarNombre(nombre);
        Files.createDirectories(carpetaDatos);

        Path archivo = carpetaDatos.resolve(nombre + ".dat");

        try (ObjectOutputStream salida = new ObjectOutputStream(
                Files.newOutputStream(archivo))) {
            salida.writeObject(objeto);
        }
    }

    public Object cargarObjeto(String nombre)
            throws IOException, ClassNotFoundException {
        validarNombre(nombre);

        Path archivo = carpetaDatos.resolve(nombre + ".dat");

        if (!Files.exists(archivo)) {
            return null;
        }

        try (ObjectInputStream entrada = new ObjectInputStream(
                Files.newInputStream(archivo))) {
            return entrada.readObject();
        }
    }

    private void validarNombre(String nombre) {
        if (nombre == null || !nombre.matches("[A-Za-z0-9_-]+")) {
            throw new IllegalArgumentException("Nombre inválido");
        }
    }
}
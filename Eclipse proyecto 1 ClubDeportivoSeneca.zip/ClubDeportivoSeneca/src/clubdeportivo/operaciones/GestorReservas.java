package clubdeportivo.operaciones;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GestorReservas implements Serializable {

    private static final long serialVersionUID = 1L;

    private final List<ReservaInstalacion> reservas =
            new ArrayList<ReservaInstalacion>();

    public boolean reservar(
            String id,
            Instalacion instalacion,
            LocalDateTime inicio,
            LocalDateTime fin) {

        if (!datosValidos(instalacion, inicio, fin)
                || buscarConflicto(instalacion, inicio, fin)) {
            return false;
        }

        reservas.add(new ReservaInstalacion(
                id, instalacion, inicio, fin, "CONFIRMADA"
        ));
        return true;
    }

    public boolean bloquearHorario(
            String id,
            Instalacion instalacion,
            LocalDateTime inicio,
            LocalDateTime fin) {

        if (!datosValidos(instalacion, inicio, fin)
                || buscarConflicto(instalacion, inicio, fin)) {
            return false;
        }

        reservas.add(new ReservaInstalacion(
                id, instalacion, inicio, fin, "BLOQUEADA"
        ));
        return true;
    }

    public boolean cancelar(String id) {
        for (ReservaInstalacion reserva : reservas) {
            if (reserva.getId().equalsIgnoreCase(id)
                    && !"CANCELADA".equalsIgnoreCase(reserva.getEstado())) {
                reserva.cancelar();
                return true;
            }
        }

        return false;
    }

    public List<ReservaInstalacion> getReservas() {
        return Collections.unmodifiableList(reservas);
    }

    private boolean datosValidos(
            Instalacion instalacion,
            LocalDateTime inicio,
            LocalDateTime fin) {

        return instalacion != null
                && inicio != null
                && fin != null
                && instalacion.estaDisponible(inicio, fin);
    }

    private boolean buscarConflicto(
            Instalacion instalacion,
            LocalDateTime inicio,
            LocalDateTime fin) {

        for (ReservaInstalacion reserva : reservas) {
            if ("CANCELADA".equalsIgnoreCase(reserva.getEstado())) {
                continue;
            }

            boolean mismaInstalacion =
                    reserva.getInstalacion().getNombre()
                            .equalsIgnoreCase(instalacion.getNombre());

            boolean horariosSeCruzan =
                    inicio.isBefore(reserva.getFin())
                    && fin.isAfter(reserva.getInicio());

            if (mismaInstalacion && horariosSeCruzan) {
                return true;
            }
        }

        return false;
    }
}
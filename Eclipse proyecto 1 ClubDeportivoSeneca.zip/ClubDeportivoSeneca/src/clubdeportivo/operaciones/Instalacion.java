package clubdeportivo.operaciones;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Instalacion implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String nombre;
    private final String tipo;
    private final int capacidad;
    private String estado;
    private final boolean permiteBebidaCaliente;

    public Instalacion(String nombre, String tipo, int capacidad,
                       String estado, boolean permiteBebidaCaliente) {
        if (nombre == null || nombre.isBlank() || capacidad <= 0) {
            throw new IllegalArgumentException("Instalación inválida");
        }

        this.nombre = nombre;
        this.tipo = tipo == null ? "" : tipo;
        this.capacidad = capacidad;
        this.estado = estado == null ? "DISPONIBLE" : estado;
        this.permiteBebidaCaliente = permiteBebidaCaliente;
    }

    public boolean estaDisponible(LocalDateTime inicio, LocalDateTime fin) {
        return inicio != null
                && fin != null
                && fin.isAfter(inicio)
                && "DISPONIBLE".equalsIgnoreCase(estado);
    }

    public boolean permiteBebidaCaliente() {
        return permiteBebidaCaliente;
    }

    public String getNombre() { return nombre; }
    public String getTipo() { return tipo; }
    public int getCapacidad() { return capacidad; }
    public String getEstado() { return estado; }

    public void setEstado(String estado) {
        if (estado != null && !estado.isBlank()) {
            this.estado = estado;
        }
    }
}
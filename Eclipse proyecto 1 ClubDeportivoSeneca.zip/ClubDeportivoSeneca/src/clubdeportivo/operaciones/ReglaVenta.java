package clubdeportivo.operaciones;

import java.io.Serializable;

public class ReglaVenta implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final double IVA_TIENDA = 0.19;
    public static final double IMPUESTO_CAFETERIA = 0.08;
    public static final double PROPINA_SUGERIDA = 0.10;
    public static final double PORCENTAJE_PUNTOS = 0.02;

    public double calcularImpuesto(String tipo, double subtotal) {
        if (subtotal < 0) {
            throw new IllegalArgumentException("Subtotal inválido");
        }

        if ("CAFETERIA".equalsIgnoreCase(tipo)) {
            return subtotal * IMPUESTO_CAFETERIA;
        }

        return subtotal * IVA_TIENDA;
    }

    public double calcularPropina(double subtotal, double porcentaje) {
        if (subtotal < 0 || porcentaje < 0) {
            throw new IllegalArgumentException("Valores inválidos");
        }

        return subtotal * porcentaje;
    }

    public int calcularPuntos(double valorCompra) {
        if (valorCompra < 0) {
            throw new IllegalArgumentException("Compra inválida");
        }

        return (int) Math.floor(valorCompra * PORCENTAJE_PUNTOS);
    }

    public boolean validarBebidaCaliente(
            Bebida bebida, Instalacion instalacion) {
        return bebida == null
                || !bebida.esCaliente()
                || instalacion == null
                || instalacion.permiteBebidaCaliente();
    }
}
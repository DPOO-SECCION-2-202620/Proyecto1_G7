package clubdeportivo.operaciones;

import java.util.ArrayList;
import java.util.List;

public class PruebaPersistenciaOperaciones {

    public static void main(String[] args) throws Exception {
        Inventario inventario = new Inventario();
        Producto balon = new Producto(
                "BAL01", "Balon", 50000, 5, "TIENDA"
        );
        inventario.agregarProducto(balon);

        Caja caja = new Caja(inventario);
        List<DetalleVenta> detalles = new ArrayList<DetalleVenta>();
        detalles.add(new DetalleVenta(balon, 2));

        Venta venta = caja.registrarVenta(
                "V-001",
                "TIENDA",
                detalles,
                null,
                new CuentaFidelidad(),
                false
        );

        if (venta == null) {
            System.out.println("No se pudo registrar la venta.");
            return;
        }

        PersistenciaOperaciones persistencia =
                new PersistenciaOperaciones("datosClub");

        persistencia.guardar(
                inventario,
                caja,
                new ArrayList<Turno>(),
                new ArrayList<Instalacion>()
        );

        PersistenciaOperaciones.DatosOperaciones cargados =
                persistencia.cargar();

        System.out.println(
                "Ventas guardadas: " + cargados.getCaja().getVentas().size()
        );
        System.out.println(
                "Existencias guardadas: "
                        + cargados.getInventario()
                                .consultarExistencias("BAL01")
        );
    }
}
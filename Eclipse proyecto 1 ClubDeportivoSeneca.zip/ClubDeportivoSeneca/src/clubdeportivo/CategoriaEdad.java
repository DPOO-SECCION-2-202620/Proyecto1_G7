package clubdeportivo;

public class CategoriaEdad extends Categoria {

    private String nombreCategoria;

    public CategoriaEdad(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }
}
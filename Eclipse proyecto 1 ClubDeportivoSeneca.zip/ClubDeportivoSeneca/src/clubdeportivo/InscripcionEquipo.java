package clubdeportivo;

public class InscripcionEquipo {

    private PerfilJugador jugador;
    private Equipo equipo;
    private String posicion;
    private int numeroCamiseta;

    public InscripcionEquipo(
            PerfilJugador jugador,
            Equipo equipo,
            String posicion,
            int numeroCamiseta) {
        this.jugador = jugador;
        this.equipo = equipo;
        this.posicion = posicion;
        this.numeroCamiseta = numeroCamiseta;
    }

    public PerfilJugador getJugador() {
        return jugador;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public String getPosicion() {
        return posicion;
    }

    public int getNumeroCamiseta() {
        return numeroCamiseta;
    }
}
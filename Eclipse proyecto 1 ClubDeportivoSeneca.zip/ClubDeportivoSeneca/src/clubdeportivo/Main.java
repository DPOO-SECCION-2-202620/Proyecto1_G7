package clubdeportivo;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ClubDeportivo club = new ClubDeportivo();

        // Datos de ejemplo para poder probar el menú
        Socio socioInicial = new Socio("socio01", "clave123", 16);
        club.agregarSocio(socioInicial);

        DeporteConjunto futbol = new DeporteConjunto("Futbol", 7);
        DeporteConjunto baloncesto = new DeporteConjunto("Baloncesto", 5);
        CategoriaEdad sub17 = new CategoriaEdad("Sub-17");

        club.agregarEquipo(new Equipo(
                "Seneca Juvenil",
                18,
                futbol,
                sub17
        ));

        club.agregarEquipo(new Equipo(
                "Seneca Baloncesto",
                12,
                baloncesto,
                sub17
        ));

        System.out.println("=== Inicio de sesion ===");
        System.out.print("Login: ");
        String login = teclado.nextLine();

        System.out.print("Contrasena: ");
        String contrasena = teclado.nextLine();

        Socio socio = club.iniciarSesionSocio(login, contrasena);

        if (socio == null) {
            System.out.println("Login o contrasena incorrectos.");
            teclado.close();
            return;
        }

        PerfilJugador perfil = new PerfilJugador(socio);
        int opcion = -1;

        while (opcion != 0) {
            System.out.println("\n=== Club Deportivo Seneca ===");
            System.out.println("1. Ver equipos");
            System.out.println("2. Inscribirme en un equipo");
            System.out.println("3. Ver mis inscripciones");
            System.out.println("0. Salir");
            System.out.print("Elige una opcion: ");

            if (!teclado.hasNextInt()) {
                System.out.println("Escribe el numero de una opcion.");
                teclado.nextLine();
                continue;
            }

            opcion = teclado.nextInt();
            teclado.nextLine();

            if (opcion == 1) {
                System.out.println("\n=== Equipos disponibles ===");

                for (int i = 0; i < club.getEquipos().size(); i++) {
                    Equipo equipo = club.getEquipos().get(i);

                    System.out.println(
                            (i + 1) + ". "
                            + equipo.getNombreEquipo()
                            + " - " + equipo.getDeporte().getNombre()
                            + " - Cupo: " + equipo.getCupoMax()
                    );
                }

            } else if (opcion == 2) {
                System.out.println("\n=== Equipos disponibles ===");

                for (int i = 0; i < club.getEquipos().size(); i++) {
                    Equipo equipo = club.getEquipos().get(i);

                    System.out.println(
                            (i + 1) + ". "
                            + equipo.getNombreEquipo()
                            + " - " + equipo.getDeporte().getNombre()
                    );
                }

                System.out.print("Numero del equipo: ");

                if (!teclado.hasNextInt()) {
                    System.out.println("Debes escribir un numero.");
                    teclado.nextLine();
                    continue;
                }

                int numeroEquipo = teclado.nextInt();
                teclado.nextLine();

                if (numeroEquipo < 1
                        || numeroEquipo > club.getEquipos().size()) {
                    System.out.println("Ese equipo no existe.");
                    continue;
                }

                Equipo equipoElegido =
                        club.getEquipos().get(numeroEquipo - 1);

                System.out.print("Posicion: ");
                String posicion = teclado.nextLine();

                System.out.print("Numero de camiseta: ");

                if (!teclado.hasNextInt()) {
                    System.out.println("El numero de camiseta debe ser numerico.");
                    teclado.nextLine();
                    continue;
                }

                int numeroCamiseta = teclado.nextInt();
                teclado.nextLine();

                InscripcionEquipo inscripcion = new InscripcionEquipo(
                        perfil,
                        equipoElegido,
                        posicion,
                        numeroCamiseta
                );

                boolean registrada =
                        club.agregarInscripcionEquipo(inscripcion);

                if (registrada) {
                    System.out.println("Inscripcion registrada.");
                } else {
                    System.out.println(
                            "No se pudo registrar. Revisa cupo, edad, "
                            + "deporte y numero de camiseta."
                    );
                }

            } else if (opcion == 3) {
                System.out.println("\n=== Mis inscripciones ===");

                for (InscripcionEquipo inscripcion
                        : club.consultarInscripcionesDe(socio)) {
                    System.out.println(
                            inscripcion.getEquipo().getNombreEquipo()
                            + " - "
                            + inscripcion.getEquipo().getDeporte().getNombre()
                            + " - "
                            + inscripcion.getPosicion()
                            + " - Camiseta "
                            + inscripcion.getNumeroCamiseta()
                    );
                }

            } else if (opcion != 0) {
                System.out.println("Opcion no valida.");
            }
        }

        System.out.println("Sesion finalizada.");
        teclado.close();
    }
}
package clubdeportivo;

public class DeporteConjunto extends Deporte {

    private int minimoJugadores;

    public DeporteConjunto(String nombre, int minimoJugadores) {
        super(nombre);
        this.minimoJugadores = minimoJugadores;
    }

    public int getMinimoJugadores() {
        return minimoJugadores;
    }

    public void setMinimoJugadores(int minimoJugadores) {
        this.minimoJugadores = minimoJugadores;
    }
}
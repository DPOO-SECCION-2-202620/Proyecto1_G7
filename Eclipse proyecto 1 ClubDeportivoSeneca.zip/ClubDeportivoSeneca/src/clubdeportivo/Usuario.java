package clubdeportivo;

public abstract class Usuario {

    private String login;
    private String contrasena;

    public Usuario(String login, String contrasena) {
        this.login = login;
        this.contrasena = contrasena;
    }

    public String getLogin() {
        return login;
    }

    public String getContrasena() {
        return contrasena;
    }
}